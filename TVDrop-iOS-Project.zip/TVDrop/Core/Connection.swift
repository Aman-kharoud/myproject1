import Foundation
import Network

// All blocking calls run on a worker queue, never on the main or Network queue.
final class Reply<Value> {
    private let lock = NSLock()
    private let signal = DispatchSemaphore(value: 0)
    private var result: Result<Value, Error>?

    func finish(_ result: Result<Value, Error>) {
        lock.lock()
        guard self.result == nil else { lock.unlock(); return }
        self.result = result
        lock.unlock()
        signal.signal()
    }

    func wait(seconds: Double = 30) throws -> Value {
        guard signal.wait(timeout: .now() + seconds) == .success else {
            throw TransferError("Connection timed out. Keep both apps open on the same Wi-Fi network.")
        }
        lock.lock()
        let value = result!
        lock.unlock()
        return try value.get()
    }
}

final class Connection {
    private let raw: NWConnection
    private let queue = DispatchQueue(label: "TVDrop.network.\(UUID().uuidString)")
    private let lock = NSLock()
    private var cancelled = false

    init(_ raw: NWConnection) { self.raw = raw }
    convenience init(endpoint: NWEndpoint) { self.init(NWConnection(to: endpoint, using: .tcp)) }

    func cancel() {
        lock.lock(); cancelled = true; lock.unlock()
        raw.cancel()
    }

    func checkCancellation() throws {
        lock.lock(); let stopped = cancelled; lock.unlock()
        if stopped { throw TransferError("Transfer cancelled.") }
    }

    func open() throws {
        try checkCancellation()
        let reply = Reply<Bool>()
        raw.stateUpdateHandler = { state in
            switch state {
            case .ready: reply.finish(.success(true))
            case .failed(let error): reply.finish(.failure(error))
            case .cancelled: reply.finish(.failure(TransferError("Transfer cancelled.")))
            default: break
            }
        }
        raw.start(queue: queue)
        _ = try reply.wait(seconds: 15)
    }

    func send(_ kind: Wire.Kind, _ data: Data = Data()) throws {
        try checkCancellation()
        let reply = Reply<Bool>()
        raw.send(content: try Wire.encode(kind, data), completion: .contentProcessed { error in
            if let error { reply.finish(.failure(error)) }
            else { reply.finish(.success(true)) }
        })
        _ = try reply.wait()
    }

    private func readExactly(_ count: Int) throws -> Data {
        var output = Data()
        while output.count < count {
            try checkCancellation()
            let reply = Reply<Data>()
            let remaining = count - output.count
            raw.receive(minimumIncompleteLength: 1, maximumLength: remaining) { data, _, complete, error in
                if let error { reply.finish(.failure(error)) }
                else if let data, !data.isEmpty { reply.finish(.success(data)) }
                else { reply.finish(.failure(TransferError(complete ? "The other device disconnected." : "No data received."))) }
            }
            output.append(try reply.wait())
        }
        return output
    }

    func receive() throws -> Wire.Packet {
        let (kind, count) = try Wire.parseHeader(readExactly(5))
        return Wire.Packet(kind: kind, payload: try readExactly(count))
    }
}
