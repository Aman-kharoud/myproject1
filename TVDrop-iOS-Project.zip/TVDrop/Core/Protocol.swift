import Foundation

struct TransferError: LocalizedError {
    let message: String
    init(_ message: String) { self.message = message }
    var errorDescription: String? { message }
}

enum Wire {
    static let serviceType = "_nitroshare._tcp"
    static let port: UInt16 = 40818
    static let chunkSize = 65_536
    static let maxPayload = 4 * 1024 * 1024
    static let maxTransfer: Int64 = 20 * 1024 * 1024 * 1024
    static let maxItems = 1000

    enum Kind: UInt8 { case success = 0, error = 1, json = 2, binary = 3 }
    struct Packet {
        let kind: Kind
        let payload: Data
    }

    // The APK includes the one-byte type in the encoded size.
    static func encode(_ kind: Kind, _ payload: Data = Data()) throws -> Data {
        guard payload.count <= maxPayload else { throw TransferError("Packet is too large.") }
        let length = UInt32(payload.count + 1)
        var result = Data((0..<4).map { UInt8(truncatingIfNeeded: length >> ($0 * 8)) })
        result.append(kind.rawValue)
        result.append(payload)
        return result
    }

    static func parseHeader(_ data: Data) throws -> (Kind, Int) {
        guard data.count == 5 else { throw TransferError("Incomplete packet header.") }
        let bytes = Array(data)
        let length = (0..<4).reduce(UInt32(0)) { $0 | UInt32(bytes[$1]) << ($1 * 8) }
        guard length >= 1, length <= UInt32(maxPayload + 1),
              let kind = Kind(rawValue: bytes[4]) else {
            throw TransferError("The other device sent an invalid packet.")
        }
        return (kind, Int(length) - 1)
    }

    static func json(_ value: [String: Any]) throws -> Data {
        try JSONSerialization.data(withJSONObject: value, options: [.sortedKeys])
    }

    static func object(_ packet: Packet) throws -> [String: Any] {
        if packet.kind == .error {
            throw TransferError(String(data: packet.payload, encoding: .utf8) ?? "The other device rejected the transfer.")
        }
        guard packet.kind == .json,
              let object = try JSONSerialization.jsonObject(with: packet.payload) as? [String: Any] else {
            throw TransferError("Expected file information from the other device.")
        }
        return object
    }

    static func number(_ object: [String: Any], _ key: String) throws -> Int64 {
        guard let text = object[key] as? String, !text.isEmpty,
              text.utf8.allSatisfy({ $0 >= 48 && $0 <= 57 }), let value = Int64(text) else {
            throw TransferError("Invalid \(key) in transfer information.")
        }
        return value
    }

    static func filename(_ name: String) throws -> String {
        guard !name.isEmpty, name != ".", name != "..", name.utf8.count <= 240,
              !name.contains("/"), !name.contains("\\"), !name.contains(":"),
              !name.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) }) else {
            throw TransferError("Unsupported filename. Send individual files without folder paths.")
        }
        return name
    }

    static func transferHeader(name: String, count: Int, size: Int64) -> [String: Any] {
        ["name": name, "count": String(count), "size": String(size)]
    }

    static func fileHeader(name: String, size: Int64, modified: Int64) -> [String: Any] {
        ["type": "file", "name": name, "size": String(size), "directory": false,
         "read_only": false, "executable": false, "last_modified": String(modified),
         "created": "0", "last_read": "0"]
    }
}
