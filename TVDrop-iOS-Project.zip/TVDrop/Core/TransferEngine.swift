import Foundation

enum TransferEngine {
    typealias Progress = (Double, String) -> Void

    static func send(urls: [URL], name: String, connection: Connection, progress: Progress) throws {
        guard !urls.isEmpty, urls.count <= Wire.maxItems else { throw TransferError("Choose between 1 and 1,000 files.") }
        let accessed = urls.filter { $0.startAccessingSecurityScopedResource() }
        defer { accessed.forEach { $0.stopAccessingSecurityScopedResource() } }
        var files: [(URL, String, Int64, Int64)] = []
        var total: Int64 = 0
        for url in urls {
            try connection.checkCancellation()
            let properties = try url.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey, .contentModificationDateKey])
            guard properties.isRegularFile == true, let size = properties.fileSize, size >= 0 else {
                throw TransferError("Select individual files. Download cloud files in Files first if needed.")
            }
            guard Int64(size) <= Wire.maxTransfer - total else { throw TransferError("Choose up to 20 GB per transfer.") }
            total += Int64(size)
            files.append((url, try Wire.filename(url.lastPathComponent), Int64(size),
                          Int64((properties.contentModificationDate?.timeIntervalSince1970 ?? 0) * 1000)))
        }
        progress(0, "Connecting…")
        try connection.open()
        try connection.send(.json, Wire.json(Wire.transferHeader(name: name, count: files.count, size: total)))
        var sent: Int64 = 0
        var lastProgress = Date.distantPast
        for (url, filename, size, modified) in files {
            try connection.send(.json, Wire.json(Wire.fileHeader(name: filename, size: size, modified: modified)))
            let file = try FileHandle(forReadingFrom: url)
            defer { try? file.close() }
            var remaining = size
            progress(total == 0 ? 0 : Double(sent) / Double(total), "Sending \(filename)")
            while remaining > 0 {
                let data = try file.read(upToCount: Int(min(Int64(Wire.chunkSize), remaining))) ?? Data()
                guard !data.isEmpty else { throw TransferError("The selected file changed during transfer. Try again.") }
                try connection.send(.binary, data)
                remaining -= Int64(data.count)
                sent += Int64(data.count)
                if Date().timeIntervalSince(lastProgress) > 0.1 {
                    progress(total == 0 ? 0 : Double(sent) / Double(total), "Sending \(filename)")
                    lastProgress = Date()
                }
            }
        }
        progress(1, "Waiting for the TV to confirm…")
        let acknowledgement = try connection.receive()
        if acknowledgement.kind == .error {
            throw TransferError(String(data: acknowledgement.payload, encoding: .utf8) ?? "The TV rejected the transfer.")
        }
        guard acknowledgement.kind == .success, acknowledgement.payload.isEmpty else {
            throw TransferError("The TV did not confirm the transfer.")
        }
    }

    static func receive(connection: Connection, documents: URL, progress: Progress) throws -> [URL] {
        try connection.open()
        let header = try Wire.object(connection.receive())
        let count = try Wire.number(header, "count")
        let total = try Wire.number(header, "size")
        guard count > 0, count <= Wire.maxItems, total <= Wire.maxTransfer else {
            throw TransferError("Transfer exceeds the limit of 1,000 files or 20 GB.")
        }
        let manager = FileManager.default
        let space = try manager.attributesOfFileSystem(forPath: documents.path)[.systemFreeSize] as? NSNumber
        guard let space, total < max(0, space.int64Value - 64 * 1024 * 1024) else {
            throw TransferError("There is not enough free space on this iPhone.")
        }
        let id = UUID().uuidString
        let staging = manager.temporaryDirectory.appendingPathComponent("TVDrop-\(id)", isDirectory: true)
        try manager.createDirectory(at: staging, withIntermediateDirectories: true)
        defer { try? manager.removeItem(at: staging) }
        var names: [String] = []
        var seen = Set<String>()
        var received: Int64 = 0
        var lastProgress = Date.distantPast
        for _ in 0..<Int(count) {
            let item = try Wire.object(connection.receive())
            guard (item["type"] as? String ?? "file") == "file", (item["directory"] as? Bool ?? false) == false,
                  let rawName = item["name"] as? String else { throw TransferError("Only regular files are supported.") }
            let name = try Wire.filename(rawName)
            guard seen.insert(name.precomposedStringWithCanonicalMapping.lowercased()).inserted else {
                throw TransferError("Two files have the same name. Send them separately.")
            }
            let size = try Wire.number(item, "size")
            guard size <= total - received else { throw TransferError("File size does not match the transfer.") }
            let destination = staging.appendingPathComponent(name)
            guard manager.createFile(atPath: destination.path, contents: nil) else { throw TransferError("Could not create the received file.") }
            let file = try FileHandle(forWritingTo: destination)
            defer { try? file.close() }
            var remaining = size
            progress(total == 0 ? 0 : Double(received) / Double(total), "Receiving \(name)")
            while remaining > 0 {
                let packet = try connection.receive()
                if packet.kind == .error {
                    throw TransferError(String(data: packet.payload, encoding: .utf8) ?? "The sender cancelled.")
                }
                guard packet.kind == .binary, !packet.payload.isEmpty, Int64(packet.payload.count) <= remaining else {
                    throw TransferError("Invalid file content from the sender.")
                }
                try file.write(contentsOf: packet.payload)
                remaining -= Int64(packet.payload.count)
                received += Int64(packet.payload.count)
                if Date().timeIntervalSince(lastProgress) > 0.1 {
                    progress(total == 0 ? 0 : Double(received) / Double(total), "Receiving \(name)")
                    lastProgress = Date()
                }
            }
            try file.synchronize()
            try file.close()
            names.append(name)
        }
        guard received == total else { throw TransferError("The transfer ended with a different size than expected.") }
        try connection.checkCancellation()
        let parent = documents.appendingPathComponent("Received", isDirectory: true)
        try manager.createDirectory(at: parent, withIntermediateDirectories: true)
        let destination = parent.appendingPathComponent("Transfer-\(id)", isDirectory: true)
        try manager.moveItem(at: staging, to: destination)
        do { try connection.send(.success) }
        catch { throw TransferError("Files were saved in Files → TVDrop → Received, but the sender disconnected before confirmation.") }
        return names.map { destination.appendingPathComponent($0) }
    }
}
