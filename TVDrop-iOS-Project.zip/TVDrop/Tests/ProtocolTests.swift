import XCTest
import Foundation
import Network
@testable import TVDropCore

final class ProtocolTests: XCTestCase {
    func testSuccessPacketIncludesTypeInLength() throws {
        XCTAssertEqual(try Wire.encode(.success), Data([1, 0, 0, 0, 0]))
    }

    func testBinaryFixture() throws {
        XCTAssertEqual(try Wire.encode(.binary, Data([0x41, 0x42, 0x43])), Data([4, 0, 0, 0, 3, 65, 66, 67]))
        let (kind, size) = try Wire.parseHeader(Data([4, 0, 0, 0, 3]))
        XCTAssertEqual(kind, .binary)
        XCTAssertEqual(size, 3)
    }

    func testRejectsInvalidHeaders() {
        for data in [Data(), Data([0, 0, 0, 0, 0]), Data([255, 255, 255, 255, 3]),
                     Data([1, 0, 0, 0, 99]), Data([2, 0, 64, 0, 3])] {
            XCTAssertThrowsError(try Wire.parseHeader(data))
        }
    }

    func testRejectsEscapingOrAmbiguousNames() {
        for name in ["", ".", "..", "../secret", "/tmp/a", "a/b", "a\\b", "C:a", "a\u{0000}b", "a\nb"] {
            XCTAssertThrowsError(try Wire.filename(name), name)
        }
        XCTAssertEqual(try Wire.filename("Holiday 🏖️.mp4"), "Holiday 🏖️.mp4")
    }

    func testSizeIsAnUnsignedDecimalString() throws {
        XCTAssertEqual(try Wire.number(["size": "5000000000"], "size"), 5_000_000_000)
        for value in ["-1", "1.5", "9223372036854775808", "", 12, true, "+1", " 1"] as [Any] {
            XCTAssertThrowsError(try Wire.number(["size": value], "size"))
        }
    }

    func testHeadersUseAndroidStringNumbers() throws {
        let json = try Wire.json(Wire.transferHeader(name: "iPhone", count: 2, size: 123))
        let parsed = try Wire.object(Wire.Packet(kind: .json, payload: json))
        XCTAssertEqual(parsed["count"] as? String, "2")
        XCTAssertEqual(parsed["size"] as? String, "123")
        let file = Wire.fileHeader(name: "test.txt", size: 10, modified: 0)
        XCTAssertEqual(file["type"] as? String, "file")
        XCTAssertEqual(file["size"] as? String, "10")
        XCTAssertEqual(file["directory"] as? Bool, false)
    }

    func testErrorPacketBecomesAnError() {
        XCTAssertThrowsError(try Wire.object(Wire.Packet(kind: .error, payload: Data("Rejected".utf8))))
    }

    func testLocalTCPRoundTripWithMultipleChunksUnicodeAndEmptyFile() throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        let source = root.appendingPathComponent("source")
        let destination = root.appendingPathComponent("destination")
        try FileManager.default.createDirectory(at: source, withIntermediateDirectories: true)
        try FileManager.default.createDirectory(at: destination, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: root) }
        let bytes = Data((0..<200_001).map { UInt8(truncatingIfNeeded: $0) })
        let first = source.appendingPathComponent("Video 🏖️.bin")
        let empty = source.appendingPathComponent("empty.txt")
        try bytes.write(to: first)
        try Data().write(to: empty)

        let ready = expectation(description: "listener ready")
        let listener = try NWListener(using: .tcp, on: .any)
        let result = Reply<[URL]>()
        listener.stateUpdateHandler = { state in if case .ready = state { ready.fulfill() } }
        listener.newConnectionHandler = { raw in
            DispatchQueue.global().async {
                let connection = Connection(raw)
                defer { connection.cancel() }
                do { result.finish(.success(try TransferEngine.receive(connection: connection, documents: destination) { _, _ in })) }
                catch { result.finish(.failure(error)) }
            }
        }
        listener.start(queue: DispatchQueue(label: "test.listener"))
        defer { listener.cancel() }
        wait(for: [ready], timeout: 5)
        guard let port = listener.port else { XCTFail("No listening port"); return }
        let sender = Connection(endpoint: .hostPort(host: "127.0.0.1", port: port))
        defer { sender.cancel() }
        try TransferEngine.send(urls: [first, empty], name: "Test", connection: sender) { _, _ in }
        let received = try result.wait(seconds: 5)
        XCTAssertEqual(received.count, 2)
        XCTAssertEqual(try Data(contentsOf: received[0]), bytes)
        XCTAssertEqual(try Data(contentsOf: received[1]), Data())
    }

    func testCancellationBeforeConnect() {
        let connection = Connection(endpoint: .hostPort(host: "127.0.0.1", port: 40818))
        connection.cancel()
        XCTAssertThrowsError(try connection.open())
    }
}
