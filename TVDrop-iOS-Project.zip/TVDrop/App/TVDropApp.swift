import SwiftUI
import UniformTypeIdentifiers

@main
struct TVDropApp: App {
    @StateObject private var model = TransferModel()
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            ContentView(model: model)
                .preferredColorScheme(.dark)
                .tint(.mint)
                .onChange(of: scenePhase) { phase in
                    if phase == .background { model.backgrounded() }
                }
        }
    }
}

struct ContentView: View {
    @ObservedObject var model: TransferModel
    @State private var mode = 0
    @State private var importing = false
    @State private var manual = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    hero
                    Picker("Transfer direction", selection: $mode) {
                        Text("Send to TV").tag(0)
                        Text("Receive files").tag(1)
                    }
                    .pickerStyle(.segmented)
                    .disabled(model.busy)
                    .onChange(of: mode) { mode in
                        if mode == 0 { model.stopListening() }
                    }
                    if mode == 0 { sendPanel } else { receivePanel }
                    statusPanel
                    Text("Keep TVDrop open during transfers. Both devices must be on the same Wi-Fi network.")
                        .font(.footnote).foregroundStyle(.secondary)
                    Text("Independent companion for Send Files to TV. Compatibility testing on an iPhone and TV is still required.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                .padding(24)
            }
            .background(Color(red: 0.035, green: 0.065, blue: 0.12))
            .navigationTitle("TVDrop")
            .navigationBarTitleDisplayMode(.inline)
            .fileImporter(isPresented: $importing, allowedContentTypes: [.item], allowsMultipleSelection: true) { result in
                switch result {
                case .success(let urls): model.files = urls
                case .failure(let error): model.errorMessage = error.localizedDescription
                }
            }
            .alert("Transfer notice", isPresented: Binding(
                get: { model.errorMessage != nil },
                set: { if !$0 { model.errorMessage = nil } }
            )) {
                Button("OK") { model.errorMessage = nil }
            } message: { Text(model.errorMessage ?? "") }
        }
    }

    private var hero: some View {
        VStack(alignment: .leading, spacing: 14) {
            Image(systemName: mode == 0 ? "arrow.up.right.square.fill" : "arrow.down.app.fill")
                .font(.system(size: 42)).foregroundStyle(.mint)
                .accessibilityHidden(true)
            Text(mode == 0 ? "Small screen.\nBig delivery." : "Make room for\nsomething new.")
                .font(.system(size: 34, weight: .bold, design: .rounded))
                .fixedSize(horizontal: false, vertical: true)
            Text(mode == 0 ? "Your files, straight to your TV over Wi-Fi." : "Bring files from your TV to your iPhone.")
                .foregroundStyle(.secondary)
        }
        .padding(.vertical, 10)
    }

    private var sendPanel: some View {
        VStack(alignment: .leading, spacing: 20) {
            VStack(alignment: .leading, spacing: 12) {
                Label("1. Choose your files", systemImage: "doc.on.doc").font(.headline)
                Button { importing = true } label: {
                    Label(model.files.isEmpty ? "Choose files" : "Change selection", systemImage: "plus")
                        .frame(maxWidth: .infinity).padding(.vertical, 7)
                }.buttonStyle(.bordered).disabled(model.busy)
                ForEach(Array(model.files.prefix(6).enumerated()), id: \.offset) { _, url in
                    Label(url.lastPathComponent, systemImage: "doc").font(.subheadline).lineLimit(2)
                }
                if model.files.count > 6 { Text("+ \(model.files.count - 6) more files").font(.caption) }
                Text("Use Files to choose documents, videos, or APK files. To send a photo, save it to Files first.")
                    .font(.caption).foregroundStyle(.secondary)
            }.card()
            VStack(alignment: .leading, spacing: 14) {
                Label("2. Choose your TV", systemImage: "tv").font(.headline)
                Toggle("Enter address manually", isOn: $manual).font(.subheadline).disabled(model.busy)
                if manual {
                    TextField("TV IP address, e.g. 192.168.1.50", text: $model.host)
                        .keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                        .textFieldStyle(.roundedBorder).disabled(model.busy)
                    HStack {
                        Text("Port").foregroundStyle(.secondary)
                        TextField("40818", text: $model.port).keyboardType(.numberPad)
                            .textFieldStyle(.roundedBorder).disabled(model.busy)
                    }
                } else {
                    Button(model.searching ? "Search again" : "Find TVs") { model.findPeers() }
                        .buttonStyle(.bordered).disabled(model.busy)
                    Text(model.discoveryStatus).font(.caption).foregroundStyle(.secondary)
                    ForEach(model.peers) { peer in
                        Button { model.selectedPeer = peer.id } label: {
                            HStack {
                                Image(systemName: "tv")
                                Text(peer.name).foregroundStyle(.primary)
                                Spacer()
                                if model.selectedPeer == peer.id { Image(systemName: "checkmark.circle.fill") }
                            }.padding(.vertical, 8)
                        }.disabled(model.busy)
                    }
                }
                Text("On your TV, open Send Files to TV and select Receive.")
                    .font(.caption).foregroundStyle(.secondary)
            }.card()
            Button { model.send(manual: manual) } label: {
                Label("Send \(model.files.count) file(s)", systemImage: "arrow.up.right")
                    .font(.headline).frame(maxWidth: .infinity).padding(.vertical, 12)
            }
            .buttonStyle(.borderedProminent)
            .disabled(model.busy || model.files.isEmpty || (!manual && model.selectedPeer == nil))
        }
    }

    private var receivePanel: some View {
        VStack(alignment: .leading, spacing: 18) {
            VStack(alignment: .leading, spacing: 14) {
                Label(model.listening ? "Available as TVDrop iPhone" : "Ready to receive", systemImage: "wifi")
                    .font(.headline)
                Text("Start receiving here, then choose Send in the TV app and select TVDrop iPhone.")
                    .foregroundStyle(.secondary)
                Button {
                    if model.listening { model.stopListening() } else { model.startListening() }
                } label: {
                    Text(model.listening ? "Stop receiving" : "Start receiving")
                        .frame(maxWidth: .infinity).padding(.vertical, 10)
                }.buttonStyle(.borderedProminent).disabled(model.busy)
                Text("While receiving is on, devices on your Wi-Fi can send files here. Transfers use the TV app’s unencrypted local protocol.")
                    .font(.caption).foregroundStyle(.secondary)
            }.card()
            if !model.received.isEmpty {
                VStack(alignment: .leading, spacing: 14) {
                    Label("Received files", systemImage: "tray.full").font(.headline)
                    ForEach(model.received, id: \.self) { url in
                        ShareLink(item: url) {
                            HStack {
                                Image(systemName: "doc")
                                Text(url.lastPathComponent).lineLimit(2)
                                Spacer()
                                Image(systemName: "square.and.arrow.up")
                            }
                        }
                    }
                    Text("Also in Files → On My iPhone → TVDrop → Received. Each transfer has its own folder.")
                        .font(.caption).foregroundStyle(.secondary)
                }.card()
            }
        }
    }

    private var statusPanel: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Circle().fill(model.busy || model.listening ? Color.mint : Color.gray).frame(width: 8, height: 8)
                Text(model.status).font(.subheadline).accessibilityAddTraits(.updatesFrequently)
            }
            if model.busy {
                ProgressView(value: model.progress)
                Button("Cancel transfer", role: .destructive) { model.cancel() }.font(.subheadline)
            }
        }.card()
    }
}

private extension View {
    func card() -> some View {
        self.padding(18).frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 20))
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white.opacity(0.06), lineWidth: 1))
    }
}
