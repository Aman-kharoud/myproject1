import SwiftUI
import Network
import UIKit

struct Peer: Identifiable {
    let name: String
    let endpoint: NWEndpoint
    var id: String { String(describing: endpoint) }
}

@MainActor
final class TransferModel: ObservableObject {
    @Published var peers: [Peer] = []
    @Published var files: [URL] = []
    @Published var received: [URL] = []
    @Published var selectedPeer: String?
    @Published var host = ""
    @Published var port = "40818"
    @Published var status = "Ready when you are."
    @Published var discoveryStatus = "Tap Find TVs to search your Wi-Fi network."
    @Published var progress: Double = 0
    @Published var busy = false
    @Published var listening = false
    @Published var searching = false
    @Published var errorMessage: String?
    let deviceName = "TVDrop iPhone"
    private var browser: NWBrowser?
    private var listener: NWListener?
    private var active: Connection?
    private var jobID: UUID?
    private var listenerID: UUID?
    private var browserID: UUID?

    var documents: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    init() { reloadReceived() }

    func reloadReceived() {
        let root = documents.appendingPathComponent("Received", isDirectory: true)
        guard let enumerator = FileManager.default.enumerator(at: root, includingPropertiesForKeys: [.isRegularFileKey], options: [.skipsHiddenFiles]) else { return }
        received = enumerator.compactMap { item -> URL? in
            guard let url = item as? URL, (try? url.resourceValues(forKeys: [.isRegularFileKey]).isRegularFile) == true else { return nil }
            return url
        }.sorted { $0.path < $1.path }
    }

    func findPeers() {
        browser?.cancel()
        let id = UUID()
        browserID = id
        let browser = NWBrowser(for: .bonjour(type: Wire.serviceType, domain: nil), using: .tcp)
        self.browser = browser
        searching = true
        peers = []
        discoveryStatus = "Searching… Open Receive on your TV."
        browser.browseResultsChangedHandler = { [weak self] results, _ in
            let peers = results.compactMap { result -> Peer? in
                guard case let .service(name, _, _, _) = result.endpoint else { return nil }
                return Peer(name: name, endpoint: result.endpoint)
            }.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
            Task { @MainActor [weak self] in
                guard let self, self.browserID == id else { return }
                self.peers = peers
                if !peers.contains(where: { $0.id == self.selectedPeer }) { self.selectedPeer = peers.first?.id }
                self.discoveryStatus = peers.isEmpty ? "No TVs found yet. Check Wi-Fi, Local Network permission, and the TV’s Receive screen." : "Choose the TV you want to send to."
            }
        }
        browser.stateUpdateHandler = { [weak self] state in
            Task { @MainActor [weak self] in
                guard let self, self.browserID == id else { return }
                switch state {
                case .failed(let error), .waiting(let error):
                    self.discoveryStatus = "Discovery unavailable: \(error.localizedDescription). Check Settings → Privacy & Security → Local Network."
                    self.searching = false
                default: break
                }
            }
        }
        browser.start(queue: DispatchQueue(label: "TVDrop.discovery"))
    }

    func send(manual: Bool) {
        guard !busy else { return }
        let endpoint: NWEndpoint
        if manual {
            let host = self.host.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !host.isEmpty, !host.contains("/"), !host.contains(" "),
                  let value = UInt16(port), value > 0, let port = NWEndpoint.Port(rawValue: value) else {
                errorMessage = "Enter the TV’s IP address and a port between 1 and 65535. The usual port is 40818."
                return
            }
            endpoint = .hostPort(host: NWEndpoint.Host(host), port: port)
        } else {
            guard let peer = peers.first(where: { $0.id == selectedPeer }) else {
                errorMessage = "Choose a nearby TV first."
                return
            }
            endpoint = peer.endpoint
        }
        guard !files.isEmpty else { errorMessage = "Choose at least one file."; return }
        stopListening()
        let connection = Connection(endpoint: endpoint)
        let files = self.files
        let name = deviceName
        let id = begin(connection)
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            defer { connection.cancel() }
            do {
                try TransferEngine.send(urls: files, name: name, connection: connection) { fraction, message in
                    Task { @MainActor [weak self] in self?.update(id, fraction, message) }
                }
                Task { @MainActor [weak self] in self?.finish(id, message: "Sent. The TV confirmed your transfer.") }
            } catch {
                Task { @MainActor [weak self] in self?.finish(id, error: error) }
            }
        }
    }

    func startListening() {
        guard !busy, !listening else { return }
        browser?.cancel(); browser = nil; browserID = nil; searching = false; peers = []
        do {
            let listener = try NWListener(using: .tcp, on: NWEndpoint.Port(rawValue: Wire.port)!)
            let id = UUID()
            listenerID = id
            self.listener = listener
            listener.service = NWListener.Service(name: deviceName, type: Wire.serviceType)
            listener.newConnectionHandler = { [weak self] raw in
                Task { @MainActor [weak self] in
                    guard let self, self.listenerID == id, self.listening, !self.busy else { raw.cancel(); return }
                    self.accept(raw)
                }
            }
            listener.stateUpdateHandler = { [weak self] state in
                Task { @MainActor [weak self] in
                    guard let self, self.listenerID == id else { return }
                    switch state {
                    case .ready:
                        self.status = "Ready to receive as \(self.deviceName)."
                    case .failed(let error):
                        self.stopListening()
                        self.errorMessage = "Could not receive: \(error.localizedDescription)"
                    case .waiting(let error): self.status = "Waiting for the network: \(error.localizedDescription)"
                    default: break
                    }
                }
            }
            listening = true
            status = "Starting receiver…"
            UIApplication.shared.isIdleTimerDisabled = true
            listener.start(queue: DispatchQueue(label: "TVDrop.listener"))
        } catch { errorMessage = error.localizedDescription }
    }

    private func accept(_ raw: NWConnection) {
        let connection = Connection(raw)
        let id = begin(connection)
        let destination = documents
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            defer { connection.cancel() }
            do {
                let urls = try TransferEngine.receive(connection: connection, documents: destination) { fraction, message in
                    Task { @MainActor [weak self] in self?.update(id, fraction, message) }
                }
                Task { @MainActor [weak self] in
                    guard let self, self.jobID == id else { return }
                    self.received.append(contentsOf: urls)
                    self.finish(id, message: "Received \(urls.count) file(s). Saved in Files → On My iPhone → TVDrop.")
                }
            } catch {
                // The connection is closed on failure; no partial files are published.
                Task { @MainActor [weak self] in self?.finish(id, error: error) }
            }
        }
    }

    private func begin(_ connection: Connection) -> UUID {
        let id = UUID()
        jobID = id; active = connection; busy = true; progress = 0
        status = "Connecting…"
        UIApplication.shared.isIdleTimerDisabled = true
        return id
    }

    private func update(_ id: UUID, _ fraction: Double, _ message: String) {
        guard jobID == id else { return }
        progress = min(1, max(0, fraction)); status = message
    }

    private func finish(_ id: UUID, message: String = "", error: Error? = nil) {
        guard jobID == id else { return }
        busy = false; active = nil; jobID = nil
        UIApplication.shared.isIdleTimerDisabled = listening
        if let error {
            status = "Transfer did not complete."
            errorMessage = error.localizedDescription
            reloadReceived()
        } else { progress = 1; status = message }
    }

    func cancel() {
        // Keep the job busy until its worker has unwound and closed file handles.
        active?.cancel()
        status = "Cancelling…"
    }

    func stopListening() {
        listenerID = nil; listener?.cancel(); listener = nil; listening = false
        UIApplication.shared.isIdleTimerDisabled = busy
        if !busy { status = "Receiver stopped." }
    }

    func backgrounded() {
        browserID = nil; browser?.cancel(); browser = nil; searching = false
        if busy { cancel() }
        stopListening()
    }
}
